```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline

df_cons = pd.read_csv('ConstructionTimeSeriesDataV2.csv')
```


```python
df_cons.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Month</th>
      <th>Month-Year</th>
      <th>Total Construction</th>
      <th>Private Construction</th>
      <th>Public Construction</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2-Jan</td>
      <td>59516</td>
      <td>45273</td>
      <td>14243</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2-Feb</td>
      <td>58588</td>
      <td>44475</td>
      <td>14113</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>2-Mar</td>
      <td>63782</td>
      <td>49396</td>
      <td>14386</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2-Apr</td>
      <td>69504</td>
      <td>53283</td>
      <td>16221</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2-May</td>
      <td>73384</td>
      <td>55009</td>
      <td>18375</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_cons.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Month</th>
      <th>Month-Year</th>
      <th>Total Construction</th>
      <th>Private Construction</th>
      <th>Public Construction</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>141</th>
      <td>142</td>
      <td>13-Oct</td>
      <td>85193</td>
      <td>59370</td>
      <td>25823</td>
    </tr>
    <tr>
      <th>142</th>
      <td>143</td>
      <td>13-Nov</td>
      <td>77931</td>
      <td>55191</td>
      <td>22741</td>
    </tr>
    <tr>
      <th>143</th>
      <td>144</td>
      <td>13-Dec</td>
      <td>71502</td>
      <td>52132</td>
      <td>19369</td>
    </tr>
    <tr>
      <th>144</th>
      <td>145</td>
      <td>14-Jan</td>
      <td>64661</td>
      <td>47827</td>
      <td>16834</td>
    </tr>
    <tr>
      <th>145</th>
      <td>146</td>
      <td>14-Feb</td>
      <td>63368</td>
      <td>46647</td>
      <td>16721</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = df_cons.set_index('Month')
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Month-Year</th>
      <th>Total Construction</th>
      <th>Private Construction</th>
      <th>Public Construction</th>
    </tr>
    <tr>
      <th>Month</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2-Jan</td>
      <td>59516</td>
      <td>45273</td>
      <td>14243</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2-Feb</td>
      <td>58588</td>
      <td>44475</td>
      <td>14113</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2-Mar</td>
      <td>63782</td>
      <td>49396</td>
      <td>14386</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2-Apr</td>
      <td>69504</td>
      <td>53283</td>
      <td>16221</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2-May</td>
      <td>73384</td>
      <td>55009</td>
      <td>18375</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dtypes
```




    Month-Year              object
    Total Construction       int64
    Private Construction     int64
    Public Construction      int64
    dtype: object




```python

```


```python
per_private = (df_cons['Private Construction']/df_cons['Total Construction']) * 100
per_public = 100.00 - per_private

pp = ['{:.2f}%'.format(x) for x in per_private]
pc = ['{:.2f}%'.format(x) for x in per_public]

df_cons['%private'] = pp
df_cons['%public'] = pc


print(df_cons)
```

         Month Month-Year  Total Construction  Private Construction  \
    0        1      2-Jan               59516                 45273   
    1        2      2-Feb               58588                 44475   
    2        3      2-Mar               63782                 49396   
    3        4      2-Apr               69504                 53283   
    4        5      2-May               73384                 55009   
    ..     ...        ...                 ...                   ...   
    141    142     13-Oct               85193                 59370   
    142    143     13-Nov               77931                 55191   
    143    144     13-Dec               71502                 52132   
    144    145     14-Jan               64661                 47827   
    145    146     14-Feb               63368                 46647   
    
         Public Construction %private %public  
    0                  14243   76.07%  23.93%  
    1                  14113   75.91%  24.09%  
    2                  14386   77.45%  22.55%  
    3                  16221   76.66%  23.34%  
    4                  18375   74.96%  25.04%  
    ..                   ...      ...     ...  
    141                25823   69.69%  30.31%  
    142                22741   70.82%  29.18%  
    143                19369   72.91%  27.09%  
    144                16834   73.97%  26.03%  
    145                16721   73.61%  26.39%  
    
    [146 rows x 7 columns]
    


```python
fig, ax = plt.subplots()

ax.bar(x = df_cons['Month'], height = df_cons['Total Construction'], color=['Gray'])

ax1 = ax.twinx()
ax1.bar(x = df_cons['Month'], height = df_cons['Private Construction'], color=['Black'])

ax.grid(False)

ax.tick_params(axis = 'y', which = 'both', direction = 'in', width = 2, color = 'Black')

fig.suptitle('Impacts Private Construction Had on Totals During Recession')
fig.set_size_inches(7,5)
plt.legend(['Total', 'Private'])


ax.xaxis.set_label_text('Month-Year')
ax.yaxis.set_label_text('Total Construction')
ax1.yaxis.set_label_text('Private Construction')


ax.set_xlim(40, 144)
ax.set_ylim(0, 120000)
ax1.set_ylim(0,120000)

plt.show()
print('Private Construction showed a linear trend up between 2002-2007. Once the recession hit \
the Private Construction saw all time lows that lasted until late 2010. After that time, Private \
Construction began another linear trend up showing growth year over year. Throughout the years, \
Private Construction has made up, on average, ~70% of monthly Total Construction numbers. \
As Private Construction began to decline these impacts were seen on a larger scale as Total \
Construction volume shows a similar trend. Despite the percent of Public Construction impacts \
increasing for Total Construction during the 2008-2010 time range, it was not enough to counteract \
the loss seen in the Private Construction sector.')
```


    
![png](output_7_0.png)
    


    Private Construction showed a linear trend up between 2002-2007. Once the recession hit the Private Construction saw all time lows that lasted until late 2010. After that time, Private Construction began another linear trend up showing growth year over year. Throughout the years, Private Construction has made up, on average, ~70% of monthly Total Construction numbers. As Private Construction began to decline these impacts were seen on a larger scale as Total Construction volume shows a similar trend. Despite the percent of Public Construction impacts increasing for Total Construction during the 2008-2010 time range, it was not enough to counteract the loss seen in the Private Construction sector.
    


```python

```


```python

```


```python

```
